const { Article } = require('../../model/article');
module.exports = () => {
    res.send('ok')
}